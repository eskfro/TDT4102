#pragma once
#include <iostream>

class Dummy {
public:
    int *num;
    Dummy() {
        num = new int{0};
    }
    ~Dummy() {
        delete num;
    }

    Dummy& operator=(const Dummy& other) {
        if (this != &other) {
            delete num;
            num = new int{};
            *num = *(other.num);
        }
        return *this;
    }
};

void dummyTest();