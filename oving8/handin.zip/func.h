#pragma once

#include <iostream>
#include <vector>
#include "Matrix.h"

void fillInFibonacciNumbers(int* result, int length);
void printArray(int* arr, int length);
void createFibonacci();
void testert(Matrix m);
